export class CreateTimerDto {}
